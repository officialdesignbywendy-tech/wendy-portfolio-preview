/**
 * Single source of truth for public identity + contact details.
 * Every value below was copied unchanged from the existing site.
 * Do not add links that aren't Wendy's real, verified profiles.
 */
export const SITE = {
  name: "Wendy Onyia",
  brand: "Design by Wendy",
  intro:
    "I create promotional and marketing visuals that help businesses communicate their offers to drive action.",
  email: "officialdesignbywendy@gmail.com",
  phone: "09065293937",
  whatsapp: "https://wa.me/2349065293937",
  linkedin:
    "https://www.linkedin.com/in/wendy-o-573b10415?utm_source=share_via&utm_content=profile&utm_medium=member_android",
  /**
   * Instagram is intentionally empty: no verified URL exists in the project yet.
   * Paste the real profile URL here and the Instagram icon appears in the hero
   * automatically. Leave it undefined until then.
   */
  instagram: undefined as string | undefined,
} as const;
