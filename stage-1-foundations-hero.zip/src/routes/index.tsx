import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowUpRight,
  Sparkles,
  Megaphone,
  Mail,
  Linkedin,
  Phone,
  ArrowRight,
  FolderOpen,
  MousePointer2,
  Lightbulb,
  MoveRight,
  X,
} from "lucide-react";
import flyerFull from "@/assets/rhythm/flyer-full.jpg.asset.json";
import mockupBillboard from "@/assets/rhythm/mockup-billboard.png.asset.json";
import mockupPoster from "@/assets/rhythm/mockup-poster.png.asset.json";
import mockupStreet from "@/assets/rhythm/mockup-street.png.asset.json";
import mockupInstagram from "@/assets/rhythm/mockup-instagram.png.asset.json";
import divaluxeFlyer from "@/assets/case-studies/divaluxe-flyer.jpg.asset.json";
import divaluxeMockupHands from "@/assets/case-studies/divaluxe-mockup-hands.png.asset.json";
import divaluxeMockupFrame from "@/assets/case-studies/divaluxe-mockup-frame.png.asset.json";
import divaluxeMockupStudio from "@/assets/case-studies/divaluxe-mockup-studio.png.asset.json";
import glowUpEventFlyer from "@/assets/case-studies/glow-up-event-flyer.jpg.asset.json";
import glowUpMockup1 from "@/assets/case-studies/glow-up-mockup-1.png.asset.json";
import glowUpMockup2 from "@/assets/case-studies/glow-up-mockup-2.png.asset.json";
import glowUpMockup3 from "@/assets/case-studies/glow-up-mockup-3.png.asset.json";
import glowUpMockup4 from "@/assets/case-studies/glow-up-mockup-4.png.asset.json";
import wendyAboutPortrait from "@/assets/wendy-about-artboard.jpg.asset.json";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { OtherProjects } from "@/components/OtherProjects";
import { Hero } from "@/components/home/Hero";
import { Marquee } from "@/components/home/Marquee";
import { WorkWithMeButton } from "@/components/home/WorkWithMeButton";
import { SITE } from "@/lib/site";
import { sendContactMessage } from "@/lib/api/contact.functions";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Design by Wendy — Marketing & Promotional Designer" },
      {
        name: "description",
        content:
          "Design by Wendy — a Marketing & Promotional Designer creating social media graphics, campaign visuals, promotional designs, and logos that help businesses get noticed.",
      },
      { property: "og:title", content: "Design by Wendy — Marketing & Promotional Designer" },
      {
        property: "og:description",
        content:
          "Marketing & Promotional Designer creating visuals that help businesses communicate their offers and stand out.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const NAV = [
  { label: "Home", href: "#top" },
  { label: "About", href: "#about" },
  { label: "Projects", href: "#case-studies" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

const SERVICES = [
  {
    icon: Megaphone,
    title: "Marketing Design",
    desc: "Visuals designed to help businesses communicate their message, promote their offers, and connect with their audience.",
    items: [
      "Social media graphics",
      "Advertisement creatives",
      "Marketing campaign visuals",
      "Digital promotional graphics",
    ],
  },
  {
    icon: Sparkles,
    title: "Promotional Design",
    desc: "Attention-grabbing designs that help businesses promote products, services, events, offers, and special campaigns.",
    items: ["Flyers", "Posters", "Sale promotions", "Product promotions", "Event promotions"],
  },
  {
    icon: ArrowUpRight,
    title: "Logo Design",
    desc: "Memorable logo concepts designed to give businesses a strong and recognisable visual starting point.",
    items: ["Wordmarks", "Brand marks", "Visual identity concepts"],
  },
];

const PROCESS = [
  {
    title: "Understanding the brief",
    desc: "I begin by understanding the project, the brand, its audience and what it wants to communicate.",
  },
  {
    title: "Finding the direction",
    desc: "I identify the main message and explore the best creative direction to communicate it effectively.",
  },
  {
    title: "Visual exploration",
    desc: "I explore suitable visual references, shapes, concepts and creative elements that relate to the brand and its message.",
  },
  {
    title: "Typography and colour",
    desc: "I carefully select fonts, colours and visual treatments that align with the brand's identity and the feeling the design should communicate.",
  },
  {
    title: "Sketching and composition",
    desc: "I organise the information, develop the layout and explore how the different elements should work together.",
  },
  {
    title: "Design execution",
    desc: "I bring the concept to life, paying attention to visual hierarchy, detail, creativity and the purpose behind every design decision.",
  },
  {
    title: "Refinement",
    desc: "I review and refine the design to ensure the final visual communicates the intended message clearly and effectively.",
  },
];


const TOOLS = ["Adobe Photoshop", "PixelLab", "Vector Ink", "Background Remover", "PicsArt", "Snapseed", "Pinterest"];

function useReveal() {
  useEffect(() => {
    const observed = new WeakSet<HTMLElement>();
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -60px 0px" }
    );
    const observeTargets = (root: ParentNode) => {
      if (root instanceof HTMLElement && root.matches(".reveal-on-scroll") && !observed.has(root)) {
        observed.add(root);
        io.observe(root);
      }
      root.querySelectorAll<HTMLElement>(".reveal-on-scroll").forEach((element) => {
        if (observed.has(element)) return;
        observed.add(element);
        io.observe(element);
      });
    };
    observeTargets(document);
    const mutations = new MutationObserver((records) => {
      records.forEach((record) => {
        record.addedNodes.forEach((node) => {
          if (node instanceof HTMLElement) observeTargets(node);
        });
      });
    });
    mutations.observe(document.body, { childList: true, subtree: true });
    return () => {
      mutations.disconnect();
      io.disconnect();
    };
  }, []);
}

function Index() {
  useReveal();
  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <Header />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Services />
        <CaseStudies />
        <OtherProjects />

        <WhyAndProcess />
        <Testimonials />
        <Tools />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}


function Header() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#top");
  useEffect(() => {
    const sections = NAV.map(({ href }) => document.querySelector<HTMLElement>(href)).filter(
      (section): section is HTMLElement => section !== null,
    );
    if (!sections.length) return;
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setActive(`#${visible.target.id}`);
    }, { rootMargin: "-22% 0px -58% 0px", threshold: [0, 0.1, 0.35] });
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/75 backdrop-blur-2xl">
      <div className="container-x grid h-[4.25rem] grid-cols-[minmax(0,1fr)_auto] items-center gap-3 md:flex md:justify-between">
        <a href="#top" className="flex min-w-0 items-center gap-2.5" aria-label="Design by Wendy, home">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-primary/40 bg-primary/10 font-display text-lg font-bold text-primary">W</span>
          <span className="truncate font-display text-base font-semibold md:text-lg">Design by Wendy<span className="text-accent">.</span></span>
        </a>
        <nav className="hidden items-center gap-6 text-[13px] lg:flex">
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              onClick={() => setActive(n.href)}
              aria-current={active === n.href ? "location" : undefined}
              className={`relative py-2 transition-colors ${active === n.href ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              {n.label}
              <span className={`absolute bottom-0 left-0 h-px bg-accent transition-all duration-300 ${active === n.href ? "w-full" : "w-0"}`} />
            </a>
          ))}
        </nav>
        <div className="hidden shrink-0 lg:block"><WorkWithMeButton /></div>
        <button
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-border text-foreground lg:hidden"
        >
          {open ? <X className="h-4 w-4" /> : <span className="flex flex-col gap-1"><span className="h-px w-4 bg-foreground" /><span className="h-px w-4 bg-foreground" /></span>}
        </button>
      </div>
      {open && (
        <div className="border-t border-border bg-background/95 lg:hidden">
          <div className="container-x flex flex-col gap-2 py-4 text-sm">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => { setOpen(false); setActive(n.href); }}
                aria-current={active === n.href ? "location" : undefined}
                className={`py-2 ${active === n.href ? "text-accent" : "text-foreground"}`}
              >
                {n.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex items-center justify-between rounded-full bg-accent py-2 pl-5 pr-2 text-accent-foreground"
            >
              Work With Me <span className="grid h-9 w-9 place-items-center rounded-full bg-background/10"><ArrowUpRight className="h-4 w-4" /></span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

function About() {
  const portraitRef = useRef<HTMLDivElement>(null);
  const countRef = useRef<HTMLSpanElement>(null);
  const [counted, setCounted] = useState(false);
  useEffect(() => {
    const node = countRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry?.isIntersecting || counted) return;
      setCounted(true);
      const start = performance.now();
      const duration = 1300;
      const tick = (now: number) => {
        const progress = Math.min((now - start) / duration, 1);
        node.textContent = String(Math.round(progress * 60));
        if (progress < 1) window.requestAnimationFrame(tick);
      };
      window.requestAnimationFrame(tick);
    }, { threshold: 0.35 });
    observer.observe(node);
    return () => observer.disconnect();
  }, [counted]);
  const handlePortraitMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse" || !portraitRef.current) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    portraitRef.current.style.setProperty("--tilt-x", `${y * -4}deg`);
    portraitRef.current.style.setProperty("--tilt-y", `${x * 5}deg`);
  };
  const resetPortrait = () => {
    portraitRef.current?.style.setProperty("--tilt-x", "0deg");
    portraitRef.current?.style.setProperty("--tilt-y", "0deg");
  };
  return (
    <section id="about" className="relative overflow-hidden py-24 md:py-36">
      <div className="container-x relative">
        <div className="reveal-on-scroll mb-12 max-w-3xl md:mb-16">
          <p className="eyebrow">About Wendy</p>
          <h2 className="mt-4 font-display text-4xl leading-[1.06] sm:text-5xl md:text-7xl">The designer <span className="text-primary">behind the work.</span></h2>
        </div>
        <div className="grid items-start gap-8 lg:grid-cols-[0.82fr_1.18fr] lg:gap-14">
          <div className="reveal-on-scroll lg:sticky lg:top-28">
            <div ref={portraitRef} onPointerMove={handlePortraitMove} onPointerLeave={resetPortrait} className="about-portrait glass-panel relative mx-auto max-w-md overflow-hidden rounded-2xl p-3">
              <div className="relative overflow-hidden rounded-xl">
                <img src={wendyAboutPortrait.url} alt="Wendy Onyia, marketing and promotional designer" className="aspect-[4/5] w-full object-cover" loading="lazy" />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent p-5 pt-20">
                  <p className="font-display text-xl font-semibold">Wendy Onyia</p>
                  <p className="mt-1 text-sm text-muted-foreground">Marketing &amp; Promotional Designer</p>
                </div>
              </div>
              <div aria-hidden className="idea-bulb absolute right-7 top-5 grid h-11 w-11 place-items-center rounded-full border border-accent/35 bg-accent/10 text-accent"><Lightbulb className="h-5 w-5" /></div>
            </div>
            <div className="mt-5 flex items-baseline gap-3 text-primary"><span ref={countRef} className="font-display text-4xl font-bold tabular-nums">0</span><span className="text-sm text-muted-foreground">+ Projects Delivered</span></div>
          </div>
          <div className="space-y-5">
            <article className="glass-panel reveal-on-scroll rounded-xl p-6 sm:p-8">
              <p className="eyebrow">Who I am</p>
              <p className="mt-4 text-base leading-relaxed text-foreground/90 sm:text-lg">I&apos;m Wendy Onyia, a Marketing &amp; Promotional Designer who turns business offers into visuals people notice, understand and act on.</p>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">I create social media graphics, promotional visuals, campaign visuals and logos that help businesses communicate their value clearly and show up with intention.</p>
              <p className="mt-4 border-l-2 border-accent pl-4 font-display text-lg text-primary sm:text-xl">Because good design is about making the right message impossible to overlook.</p>
            </article>
            <article className="glass-panel reveal-on-scroll rounded-xl p-6 sm:p-8">
              <p className="eyebrow">My design background</p>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">Creativity has always been a part of me. Growing up, I naturally gravitated towards crafting, creating things with my hands and exploring different ways to bring ideas to life.</p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">Design felt like a natural direction because it combined my creativity with the opportunity to communicate ideas visually. That interest grew into a journey of learning, practising, experimenting and developing my skills as a Marketing &amp; Promotional Designer.</p>
            </article>
            <div className="grid gap-5 sm:grid-cols-2">
              <article className="glass-panel reveal-on-scroll rounded-xl p-6">
                <p className="eyebrow">My experience</p>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">I have created over 60 designs across different brands, industries and creative projects, from personal concepts to real projects and collaborations.</p>
                <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-foreground/80">Selected work with</p>
                <div className="mt-3 flex flex-wrap gap-2">{["Edu4U Global", "Stuck in Profit", "The Clarity Table Conference"].map((name) => <span key={name} className="rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs text-primary">{name}</span>)}</div>
              </article>
              <article className="glass-panel reveal-on-scroll rounded-xl p-6">
                <p className="eyebrow">Creative interests</p>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">I enjoy visual storytelling, bringing concepts to life and exploring unique ways to communicate ideas that make people pause, understand and remember.</p>
                <p className="eyebrow mt-5">What inspires my work</p>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">I look at the brand, its audience, the purpose and the action it wants to inspire, then turn unexpected shapes, objects and visual connections into intentional, distinctive ideas.</p>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="relative overflow-hidden py-24 md:py-36" style={{ background: "var(--gradient-editorial)" }}>
      <div className="container-x">
        <div className="reveal-on-scroll max-w-3xl">
          <p className="eyebrow">What I do</p>
          <h2 className="mt-4 font-display text-4xl leading-tight sm:text-5xl md:text-6xl">Three ways to bring <span className="text-primary">your message forward.</span></h2>
        </div>
        <div className="service-reveal reveal-on-scroll relative mt-14 md:mt-20">
          <div aria-hidden className="service-folder glass-panel relative mx-auto mb-10 grid h-20 max-w-xs place-items-center rounded-2xl text-primary"><FolderOpen className="h-10 w-10" /><span className="absolute -top-2 left-8 h-4 w-20 rounded-t-md border border-b-0 border-primary/30 bg-primary/10" /></div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-5">
            {SERVICES.map(({ icon: Icon, title, desc, items }, i) => (
              <article key={title} className="service-card glass-panel group flex flex-col rounded-xl p-6 sm:p-7" style={{ transitionDelay: `${i * 140}ms` }}>
                <div className="flex items-start justify-between"><span className="grid h-12 w-12 place-items-center rounded-xl border border-primary/30 bg-primary/10 text-primary transition-colors group-hover:border-accent/50 group-hover:text-accent"><Icon className="h-5 w-5" /></span><span className="font-display text-2xl text-accent">0{i + 1}</span></div>
                <h3 className="mt-7 font-display text-2xl font-semibold sm:text-3xl">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{desc}</p>
                <ul className="mt-6 space-y-3 border-t border-border/60 pt-5 text-sm text-foreground/85">{items.map((item) => <li key={item} className="flex items-start gap-3"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />{item}</li>)}</ul>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function CaseStudies() {
  const projects = [
    { title: "Naija Dance Challenge 2.0", category: "Event Promotion · Campaign Visual", description: "A high-energy event identity built around rhythm, movement and a clear call to action.", image: flyerFull.url, detail: <RhythmCaseStudy /> },
    { title: "Divaluxe", category: "Promotional Design · Beauty", description: "An elegant makeup studio flyer balancing premium atmosphere with useful service information.", image: divaluxeFlyer.url, detail: <DivaluxeCaseStudy /> },
    { title: "Glow Up Beauty Pop Up", category: "Event Promotion · Campaign Visual", description: "A beauty pop-up campaign designed to build anticipation and make event details easy to scan.", image: glowUpEventFlyer.url, detail: <GlowUpCaseStudy /> },
  ];
  return (
    <section id="case-studies" className="relative overflow-hidden py-24 md:py-36">
      <div className="container-x relative">
        <div className="reveal-on-scroll flex items-end justify-between gap-4">
          <div><p className="eyebrow">Selected work</p><h2 className="mt-4 font-display text-5xl font-semibold sm:text-6xl md:text-7xl">Projects<span className="text-primary">.</span></h2><p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">A closer look at promotional and campaign visuals, from the first idea to the final presentation.</p></div>
          <span className="hidden pb-2 text-sm text-muted-foreground sm:block">03 featured projects</span>
        </div>
        <div className="project-rail -mx-5 mt-10 flex gap-4 overflow-x-auto px-5 pb-5 sm:-mx-10 sm:px-10 md:mt-14 md:gap-6 md:px-10">
          {projects.map((project, i) => (
            <Dialog key={project.title}>
              <DialogTrigger asChild>
                <button type="button" className="project-rail-card glass-panel group w-[82vw] max-w-[420px] shrink-0 overflow-hidden rounded-xl text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent sm:w-[58vw] lg:w-[calc((100%-3rem)/3)]">
                  <div className="relative aspect-[4/3] overflow-hidden bg-secondary"><img src={project.image} alt={project.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.035]"/><span className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full border border-white/20 bg-background/60 text-white backdrop-blur-md"><ArrowUpRight className="h-4 w-4" /></span></div>
                  <div className="p-5 sm:p-6"><p className="eyebrow text-accent">{project.category}</p><h3 className="mt-3 font-display text-xl font-semibold sm:text-2xl">{project.title}</h3><p className="mt-3 text-sm leading-relaxed text-muted-foreground">{project.description}</p><span className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-primary">Explore project <MoveRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></span></div>
                </button>
              </DialogTrigger>
              <DialogContent className="max-h-[92vh] w-[calc(100%-1rem)] max-w-6xl overflow-y-auto border-primary/20 bg-background p-4 sm:p-7">
                <DialogTitle className="sr-only">{project.title} — project details</DialogTitle>
                {project.detail}
              </DialogContent>
            </Dialog>
          ))}
        </div>
        <p className="mt-2 text-center text-xs text-muted-foreground sm:hidden">Swipe to explore projects</p>
      </div>
    </section>
  );
}

function CaseStudyImage({
  number,
  src,
  alt,
}: {
  number: string;
  src: string;
  alt: string;
}) {
  return (
    <div className="relative group">
      <div
        className="absolute -inset-3 rounded-[2rem] opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-2xl"
        style={{ background: "var(--blush)" }}
      />
      <div className="relative overflow-hidden rounded-[1.75rem] bg-secondary" style={{ boxShadow: "var(--shadow-elegant)" }}>
        <img
          src={src}
          alt={alt}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.02]"
        />
      </div>
      <span
        className="absolute -top-4 -left-4 font-display text-7xl md:text-8xl leading-none italic opacity-90"
        style={{ color: "var(--gold-deep)" }}
      >
        {number}
      </span>
    </div>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="mt-3 space-y-2 text-[15px]" style={{ color: "var(--espresso)" }}>
      {items.map((item) => (
        <li key={item} className="flex gap-3">
          <span className="mt-2 h-1 w-3 shrink-0 bg-primary/60" />
          {item}
        </li>
      ))}
    </ul>
  );
}

function MockupGallery({
  title = "Mockups",
  images,
  altPrefix,
}: {
  title?: string;
  images: { url: string }[];
  altPrefix: string;
}) {
  return (
    <div className="mt-20 md:mt-24">
      <div className="flex items-end justify-between gap-6">
        <h4 className="font-display text-4xl md:text-5xl tracking-tight">
          {title.slice(0, 4)}
          <span className="italic font-light hl-lime">
            {title.slice(4)}
          </span>
        </h4>
        <span className="hidden md:inline-block font-display italic text-sm text-muted-foreground">
          In context
        </span>
      </div>
      <div aria-hidden className="mt-6 editorial-rule" />
      <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
        {images.map((img, i) => (
          <div key={img.url} className="overflow-hidden rounded-2xl bg-secondary" style={{ boxShadow: "var(--shadow-elegant)" }}>
            <img
              src={img.url}
              alt={`${altPrefix} mockup ${i + 1}`}
              loading="lazy"
              className="w-full h-auto"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function RhythmCaseStudy() {
  
  const mockupImages = [mockupBillboard, mockupPoster, mockupStreet, mockupInstagram];

  return (
    <article className="mt-16 md:mt-24 reveal-on-scroll">
      <div className="grid lg:grid-cols-12 gap-8 lg:gap-14 items-start">
        <div className="lg:col-span-7">
          <CaseStudyImage
            number="01"
            src={flyerFull.url}
            alt="Naija Dance Challenge 2.0 flyer design"
          />
        </div>
        <div className="lg:col-span-5">
          <p className="eyebrow">Featured Project</p>
          <h3 className="mt-3 font-display text-3xl md:text-4xl lg:text-5xl leading-[1.05] tracking-tight">
            Naija Dance Challenge 2.0 <span className="italic font-light hl-lime">— Rhythm Vibes Studio</span>
          </h3>
          <div aria-hidden className="mt-6 editorial-rule" />
          <div className="mt-6 space-y-5">
            <div>
              <p className="eyebrow !text-foreground/60">Project Type</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                Event Promotion Flyer (Self-Initiated Design Concept)
              </p>
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Overview</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                This is a design I created for a fictional dance competition aimed at grabbing the attention of young audiences through bold typography, vibrant colours, and energetic visuals. The design was created to communicate key event information while reflecting the excitement and thrill of the dance challenge.
              </p>
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Objective</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                To create a visually engaging flyer that:
              </p>
              <BulletList
                items={[
                  "Grabs attention immediately.",
                  "Highlights the ₦100,000 grand prize (what actually attracts people).",
                  "Encourages registrations.",
                  "Appeals to dance lovers and young adults specifically.",
                ]}
              />
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Target Audience</p>
              <BulletList
                items={[
                  "Young adults (18+)",
                  "Dancers",
                  "Music lovers",
                  "Event enthusiasts",
                  "Youth interested in dance competitions",
                ]}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 grid lg:grid-cols-2 gap-10 lg:gap-14">
        <div>
          <p className="eyebrow !text-foreground/60">The Challenge</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            The main challenge was presenting a large amount of event information without making the flyer feel cluttered. Another challenge was creating a design that looked energetic and modern while keeping important details easy to find.
          </p>
        </div>
        <div>
          <p className="eyebrow !text-foreground/60">Design Strategy</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            To solve these challenges, I:
          </p>
          <BulletList
            items={[
              "Used bold typography to establish a clear visual hierarchy.",
              "Highlighted the registration button with yellow to create a strong call-to-action.",
              "Chose a blue, white, and yellow colour palette to create contrast and energy.",
              "Positioned the dancers at the bottom to highlight the event theme while supporting the composition of the flier.",
              "Balanced the layout so the prize, date, and registration details remained easy to scan.",
            ]}
          />
        </div>
      </div>

      <div className="mt-16 md:mt-20">
        <div className="flex items-end justify-between gap-6">
          <h4 className="font-display text-4xl md:text-5xl tracking-tight">
            Design <span className="italic font-light hl-lime">Decisions</span>
          </h4>
        </div>
        <div aria-hidden className="mt-6 editorial-rule" />
        <div className="mt-10 grid lg:grid-cols-3 gap-10">
          <div>
            <p className="eyebrow !text-foreground/60">Typography</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              Large condensed fonts were used for the main headline to maximise impact and readability.
            </p>
          </div>
          <div>
            <p className="eyebrow !text-foreground/60">Colour</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              Yellow was introduced to emphasise important actions and key information, while blue established a vibrant and youthful identity.
            </p>
          </div>
          <div>
            <p className="eyebrow !text-foreground/60">Layout</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              All information was grouped into sections, allowing viewers to quickly locate the prize, event details, and registration instructions.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 max-w-4xl">
        <p className="eyebrow !text-foreground/60">Logo</p>
        <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
          The Rhythm Vibes logo was designed to show the energy, creativity, and emotional impact of music and live performance. At the centre is a microphone symbolising voice, expression, and performance surrounded by a semicircular form inspired by sound waves. The “RV” initials form a unified visual identity showing harmony between sound, branding, and performance.
        </p>
      </div>


      <div className="mt-16 md:mt-20 grid lg:grid-cols-2 gap-10 lg:gap-14">
        <div>
          <p className="eyebrow !text-foreground/60">Tools Used</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Pixellab", "Adobe Lightroom"].map((t) => (
              <span key={t} className="rounded-full border border-foreground/20 bg-card px-4 py-2 text-sm">
                {t}
              </span>
            ))}
          </div>
        </div>
        <div>
          <p className="eyebrow !text-foreground/60">Outcome</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            The final design delivers an energetic promotional flier that communicates essential event information while maintaining a modern and visually engaging appearance suitable for social media promotion.
          </p>
        </div>
      </div>

      <MockupGallery images={mockupImages} altPrefix="Naija Dance Challenge" />

      <div className="mt-16 md:mt-20 max-w-4xl">
        <p className="eyebrow !text-foreground/60">Reflection</p>
        <p className="mt-3 text-[15px] md:text-base leading-relaxed" style={{ color: "var(--espresso)" }}>
          This project strengthened my understanding of visual hierarchy, typography, and layout balance. If I were to revisit it, I would refine the spacing further and explore additional ways to improve readability while maintaining the same energetic aesthetic.
        </p>
      </div>
    </article>
  );
}

function DivaluxeCaseStudy() {
  const mockupImages = [divaluxeMockupHands, divaluxeMockupFrame, divaluxeMockupStudio];

  return (
    <article className="mt-20 md:mt-32 reveal-on-scroll">
      <div className="grid lg:grid-cols-12 gap-8 lg:gap-14 items-start">
        <div className="lg:col-span-7 lg:order-2">
          <CaseStudyImage
            number="02"
            src={divaluxeFlyer.url}
            alt="Divaluxe makeup studio flyer design"
          />
        </div>
        <div className="lg:col-span-5 lg:order-1">
          <p className="eyebrow">Case Study</p>
          <h3 className="mt-3 font-display text-3xl md:text-4xl lg:text-5xl leading-[1.05] tracking-tight">
            Divaluxe <span className="italic font-light hl-lime">— Makeup Studio Flyer</span>
          </h3>
          <div aria-hidden className="mt-6 editorial-rule" />
          <div className="mt-6 space-y-5">
            <div>
              <p className="eyebrow !text-foreground/60">Project Type</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                Promotional Flyer Design (Self-Initiated Design Concept)
              </p>
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Overview</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                I designed this promotional flyer for a hypothetical beauty brand to showcase its makeup services, beauty products, and training classes. The goal was to achieve a feminine, elegant, and inviting design that reflects the brand&apos;s identity while communicating its offerings clearly.
              </p>
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Objective</p>
              <BulletList
                items={[
                  "Promote the makeup studio's services.",
                  "Increase awareness of beauty products and classes.",
                  "Create a premium and luxury brand image.",
                  "Encourage potential customers to make enquiries.",
                ]}
              />
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Target Audience</p>
              <BulletList
                items={[
                  "Women and girls interested in beauty and makeup.",
                  "Aspiring makeup artists.",
                  "Brides and event attendees.",
                  "People looking for beauty products or makeup training.",
                ]}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 grid lg:grid-cols-2 gap-10 lg:gap-14">
        <div>
          <p className="eyebrow !text-foreground/60">The Challenge</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            The challenge was to present multiple services within one flyer while consistently maintaining a clean layout and the brand&apos;s elegant, feminine identity.
          </p>
        </div>
        <div>
          <p className="eyebrow !text-foreground/60">Design Strategy</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            To achieve this, I:
          </p>
          <BulletList
            items={[
              "Used a soft pink and gold colour palette to communicate elegance and luxury.",
              "Placed the makeup bag and cosmetics at the centre to establish the theme.",
              "Organised the services into three clear sections using icons for quick recognition.",
              "Added subtle beauty-themed illustrations in the background to create depth without distracting from the content.",
              "Used decorative typography for the tagline while keeping the remaining text readable.",
            ]}
          />
        </div>
      </div>

      <div className="mt-16 md:mt-20">
        <div className="flex items-end justify-between gap-6">
          <h4 className="font-display text-4xl md:text-5xl tracking-tight">
            Design <span className="italic font-light hl-lime">Decisions</span>
          </h4>
        </div>
        <div aria-hidden className="mt-6 editorial-rule" />
        <div className="mt-10 grid lg:grid-cols-2 gap-10 lg:gap-14">
          <div>
            <p className="eyebrow !text-foreground/60">Colour</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              Soft pink and gold were chosen to show femininity, sophistication, and luxury.
            </p>
          </div>
          <div>
            <p className="eyebrow !text-foreground/60">Typography</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              An elegant serif typography was paired with a handwritten script to balance professionalism with personality.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 grid lg:grid-cols-2 gap-10 lg:gap-14">
        <div>
          <p className="eyebrow !text-foreground/60">Logo</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            For the divaluxe logo, the illustrated female figure represents the brand&apos;s focus on makeup artistry and self-expression, while the crown symbolizes luxury, excellence, and making every client feel like royalty. The circular frame creates a more balanced look, and the gold colour emphasizes the brand&apos;s premium and sophisticated identity.
          </p>
        </div>
        <div>
          <p className="eyebrow !text-foreground/60">Tools Used</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <span className="rounded-full border border-foreground/20 bg-card px-4 py-2 text-sm">Pixellab</span>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 max-w-4xl">
        <p className="eyebrow !text-foreground/60">Outcome</p>
        <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
          The final design presents Divaluxe as a modern and elegant beauty brand while making its services easy to understand at a glance. The flyer balances aesthetics with clear communication to engage potential clients.
        </p>
      </div>

      <MockupGallery images={mockupImages} altPrefix="Divaluxe flyer" />

      <div className="mt-16 md:mt-20 max-w-4xl">
        <p className="eyebrow !text-foreground/60">Reflection</p>
        <p className="mt-3 text-[15px] md:text-base leading-relaxed" style={{ color: "var(--espresso)" }}>
          This project allowed me to explore luxury-inspired branding through colour, typography, and composition. If I revisited the design, I would improve text readability on smaller screens.
        </p>
      </div>
    </article>
  );
}

function GlowUpCaseStudy() {
  return (
    <article className="mt-20 md:mt-32 reveal-on-scroll">
      <div className="grid lg:grid-cols-12 gap-8 lg:gap-14 items-start">
        <div className="lg:col-span-7 lg:order-2">
          <CaseStudyImage
            number="03"
            src={glowUpEventFlyer.url}
            alt="Glow Up Beauty Pop Up event flyer design"
          />
        </div>
        <div className="lg:col-span-5 lg:order-1">
          <p className="eyebrow">Case Study</p>
          <h3 className="mt-3 font-display text-3xl md:text-4xl lg:text-5xl leading-[1.05] tracking-tight">
            Glow Up <span className="italic font-light hl-lime">— Beauty Pop Up Event</span>
          </h3>
          <div aria-hidden className="mt-6 editorial-rule" />
          <div className="mt-6 space-y-5">
            <div>
              <p className="eyebrow !text-foreground/60">Project Type</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                Event Promotional Flyer (Self-Initiated Design Concept)
              </p>
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Overview</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                This flyer was designed to promote a beauty pop-up event where visitors could discover cosmetic products, interact with the brand, and participate in a limited-time shopping experience. The visual concept was built around luxury, glamour, and excitement to encourage attendance.
              </p>
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Objective</p>
              <p className="mt-1.5 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
                The project focused on:
              </p>
              <BulletList
                items={[
                  "Creating anticipation for the event.",
                  "Highlighting the beauty products as the centrepiece.",
                  "Establishing a luxurious and modern brand atmosphere.",
                  "Encouraging visitors to attend through bold promotional messaging.",
                ]}
              />
            </div>
            <div>
              <p className="eyebrow !text-foreground/60">Intended Audience</p>
              <BulletList
                items={[
                  "Makeup enthusiasts",
                  "Beauty shoppers",
                  "Young adults interested in cosmetics",
                  "Individuals looking for new beauty products and experiences",
                ]}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 grid lg:grid-cols-2 gap-10 lg:gap-14">
        <div>
          <p className="eyebrow !text-foreground/60">Challenge</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            The goal was to create an event flyer that felt luxurious and exciting while presenting essential event details in a way that remained visually balanced. The design needed to attract attention quickly and encourage attendance.
          </p>
        </div>
        <div>
          <p className="eyebrow !text-foreground/60">Design Strategy</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            To achieve this, I centred the composition around the featured beauty products and used lighting effects, elegant colours, and flowing decorative elements to create a premium atmosphere. The supporting information was carefully positioned to complement the visuals without distracting from the main message.
          </p>
        </div>
      </div>

      <div className="mt-16 md:mt-20">
        <div className="flex items-end justify-between gap-6">
          <h4 className="font-display text-4xl md:text-5xl tracking-tight">
            Design <span className="italic font-light hl-lime">Decisions</span>
          </h4>
        </div>
        <div aria-hidden className="mt-6 editorial-rule" />
        <div className="mt-10 grid lg:grid-cols-2 gap-10 lg:gap-14">
          <div>
            <p className="eyebrow !text-foreground/60">Colour Palette</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              A combination of black and gold was used to communicate elegance, exclusivity, and sophistication.
            </p>
          </div>
          <div>
            <p className="eyebrow !text-foreground/60">Typography</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              Bold headline typography creates immediate impact, while simpler supporting fonts maintain readability.
            </p>
          </div>
          <div>
            <p className="eyebrow !text-foreground/60">Layout</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              The products serve as the visual focal point, with event details arranged around them to maintain balance and hierarchy.
            </p>
          </div>
          <div>
            <p className="eyebrow !text-foreground/60">Visual Elements</p>
            <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
              Gold swirls and glowing effects were incorporated to enhance the luxurious feel and reinforce the beauty theme.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-16 md:mt-20 grid lg:grid-cols-2 gap-10 lg:gap-14">
        <div>
          <p className="eyebrow !text-foreground/60">Tools Used</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <span className="rounded-full border border-foreground/20 bg-card px-4 py-2 text-sm">Pixellab</span>
          </div>
        </div>
        <div>
          <p className="eyebrow !text-foreground/60">Outcome</p>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--espresso)" }}>
            The final promotional piece captures the excitement of a beauty pop-up while maintaining a clean visual hierarchy. Its bold presentation is suitable for social media campaigns, digital advertising, and event marketing.
          </p>
        </div>
      </div>

      <MockupGallery
        images={[glowUpMockup1, glowUpMockup2, glowUpMockup3, glowUpMockup4]}
        altPrefix="Glow Up Beauty Pop Up"
      />

      <div className="mt-16 md:mt-20 max-w-4xl">
        <p className="eyebrow !text-foreground/60">Reflection</p>
        <p className="mt-3 text-[15px] md:text-base leading-relaxed" style={{ color: "var(--espresso)" }}>
          This project gave me the opportunity to experiment with contrast, lighting, and composition to create a visually striking promotional design. It reinforced the importance of using visual storytelling to communicate the atmosphere of an event rather than relying solely on written information.
        </p>
      </div>
    </article>
  );
}

function WhyAndProcess() {
  return (
    <section id="process" className="relative overflow-hidden bg-background py-24 text-foreground md:py-36">
      <div aria-hidden className="absolute inset-0 grain-bg opacity-[0.15]" />
      <div className="container-x relative">
        <div className="reveal-on-scroll max-w-3xl">
          <p className="eyebrow"><span className="hl-lime font-bold">Why work with me</span></p>
          <h2 className="mt-5 font-display text-4xl leading-tight sm:text-5xl md:text-6xl">A clear message, <span className="text-primary">thoughtfully made.</span></h2>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">I believe good design starts with understanding what needs to be communicated. My approach combines creativity, strategic thinking and attention to detail to create visuals that have a clear purpose.</p>
        </div>

        <div className="mt-16 border-t border-border/70 pt-10 md:mt-24 md:pt-14">
          <div className="reveal-on-scroll flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div><p className="eyebrow">From first thought to final detail</p><h3 className="mt-4 font-display text-3xl sm:text-4xl md:text-5xl">My creative process<span className="text-accent">.</span></h3></div>
            <span className="font-display text-sm text-muted-foreground">Seven considered steps</span>
          </div>
          <ol className="process-list relative mt-9 grid gap-3 md:mt-12 md:grid-cols-2 xl:grid-cols-3">
            {PROCESS.map((step, index) => (
              <li key={step.title} className="process-step glass-panel reveal-on-scroll relative flex gap-4 rounded-lg p-5 sm:p-6" style={{ transitionDelay: `${(index % 3) * 85}ms` }}>
                <span className="process-number relative z-10 grid h-11 w-11 shrink-0 place-items-center rounded-full border border-primary/40 bg-background font-display text-sm font-semibold text-accent">{String(index + 1).padStart(2, "0")}</span>
                <div><h4 className="font-display text-xl font-semibold sm:text-2xl">{step.title}</h4><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.desc}</p></div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const messages = [
    "Client stories will live here.",
    "Available for new marketing and promotional design projects.",
    "Your feedback could be the first featured.",
  ];
  return (
    <section id="testimonials" className="relative overflow-hidden py-24 md:py-32">
      <div className="container-x">
        <div className="reveal-on-scroll flex flex-col justify-between gap-5 border-b border-border/70 pb-8 sm:flex-row sm:items-end md:pb-10">
          <div><p className="eyebrow">Testimonials</p><h2 className="mt-4 font-display text-4xl sm:text-5xl md:text-6xl">Client Feedback<span className="text-primary">.</span></h2></div>
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">A place for the stories behind the work, shared by the people I collaborate with.</p>
        </div>
        <div className="mt-8 grid gap-3 md:grid-cols-3 md:gap-4">
          {messages.map((message, index) => (
            <article key={message} className="glass-panel reveal-on-scroll flex min-h-40 flex-col justify-between rounded-lg p-6 sm:min-h-48 sm:p-7" style={{ transitionDelay: `${index * 100}ms` }}>
              <span aria-hidden="true" className="font-display text-4xl leading-none text-primary">“</span>
              <p className="font-display text-lg leading-snug text-foreground sm:text-xl">{message}</p>
              <span aria-hidden="true" className="mt-5 h-px w-12 bg-accent" />
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Tools() {
  return (
    <section id="tools" className="relative overflow-hidden py-24 md:py-32">
      <div className="container-x">
        <div className="grid items-start gap-10 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-5">
            <div className="reveal-on-scroll lg:sticky lg:top-32">
              <p className="eyebrow">Tools</p>
              <h2 className="mt-4 font-display text-4xl leading-tight sm:text-5xl md:text-6xl">My Everyday <span className="text-primary">Toolkit.</span></h2>
              <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground sm:text-base">The creative tools I reach for to shape ideas into finished visuals.</p>
            </div>
          </div>
          <div className="tool-stack reveal-on-scroll relative lg:col-span-7">
            <ol className="space-y-3">
              {TOOLS.map((tool, index) => (
              <li
                key={tool}
                className="tool-chip glass-panel reveal-on-scroll relative flex min-h-14 items-center gap-4 rounded-lg px-4 py-3 text-sm font-medium transition-colors hover:border-accent/60 hover:text-accent sm:px-5"
                style={{ transitionDelay: `${index * 90}ms`, animationDelay: `${index * 90}ms` }}
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md border border-primary/30 bg-primary/10 font-display text-xs font-semibold text-primary">{String(index + 1).padStart(2, "0")}</span>
                <span className="text-base text-foreground sm:text-lg">{tool}</span>
                <span aria-hidden="true" className="ml-auto h-2 w-2 rounded-full bg-accent" />
              </li>
              ))}
            </ol>
            <span className="tool-cursor pointer-events-none absolute right-2 top-0 z-10 text-accent" aria-hidden="true"><MousePointer2 className="h-6 w-6 fill-accent" /></span>
          </div>
        </div>
      </div>
    </section>
  );
}

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M.057 24l1.687-6.163a11.867 11.867 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.82 11.82 0 0 1 8.413 3.488 11.82 11.82 0 0 1 3.48 8.414c-.003 6.554-5.338 11.89-11.893 11.89a11.9 11.9 0 0 1-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 0 0 1.51 5.26l.601.96-1 3.648 3.378-.567zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.174.198-.298.297-.497.099-.198.05-.371-.025-.52-.074-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01a1.09 1.09 0 0 0-.792.372c-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z" />
    </svg>
  );
}

function Contact() {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const contacts = [
    { icon: Mail, label: SITE.email, href: `mailto:${SITE.email}` },
    { icon: Phone, label: SITE.phone, href: `tel:${SITE.phone}` },
    { icon: Linkedin, label: "LinkedIn — Wendy O.", href: SITE.linkedin },
    { icon: WhatsAppIcon, label: `WhatsApp · ${SITE.phone}`, href: SITE.whatsapp },
  ];
  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (status === "sending") return;
    const form = event.currentTarget;
    const values = new FormData(form);
    setStatus("sending");
    try {
      const result = await sendContactMessage({
        data: {
          name: String(values.get("name") ?? ""),
          email: String(values.get("email") ?? ""),
          projectType: String(values.get("projectType") ?? ""),
          message: String(values.get("message") ?? ""),
          website: String(values.get("website") ?? ""),
        },
      });
      if (result.ok) {
        setStatus("sent");
        form.reset();
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };
  return (
    <section id="contact" className="contact reveal-on-scroll relative overflow-hidden pb-24 pt-8 md:pb-32 md:pt-12">
      <div className="container-x">
        <div aria-hidden="true" className="contact-impact relative mx-auto mb-7 grid h-14 w-14 place-items-center">
          <span className="impact-core h-3 w-3 rounded-sm bg-accent" />
          {Array.from({ length: 16 }, (_, index) => <span key={index} className="pixel-particle" />)}
        </div>
        <div className="relative border-y border-border/70 py-8 md:py-12">
          <div className="relative grid gap-10 lg:grid-cols-12 lg:gap-14">
            <div className="lg:col-span-5">
              <p className="eyebrow">Get in touch</p>
              <h2 className="mt-4 font-display text-4xl leading-[1.04] sm:text-5xl md:text-6xl">
                Let&apos;s create something{" "}
                <span className="text-primary">
                  worth noticing
                </span>
                .
              </h2>
              <div className="mt-8 space-y-3 text-sm sm:mt-10">
                {contacts.map(({ icon: Icon, label, href }) => (
                  <a
                    key={label}
                    href={href}
                    target={href.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer"
                    className="flex items-center gap-3 hover:text-primary transition break-all group"
                  >
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-accent text-primary group-hover:bg-foreground group-hover:text-background transition-colors">
                      <Icon className="h-4 w-4" />
                    </span>
                    {label}
                  </a>
                ))}
              </div>
            </div>
            <form onSubmit={handleSubmit} className="glass-panel grid gap-4 rounded-xl p-5 sm:p-7 lg:col-span-7">
              <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                <label>Leave this field empty<input type="text" name="website" tabIndex={-1} autoComplete="off" /></label>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="eyebrow">Name</label>
                  <Input required name="name" autoComplete="name" maxLength={100} placeholder="Your name" className="mt-2 h-12 rounded-xl bg-background" />
                </div>
                <div>
                  <label className="eyebrow">Email</label>
                  <Input required name="email" type="email" autoComplete="email" maxLength={200} placeholder="you@email.com" className="mt-2 h-12 rounded-xl bg-background" />
                </div>
              </div>
              <div>
                <label className="eyebrow">Project type</label>
                <Input name="projectType" maxLength={200} placeholder="Marketing design, promotional graphic, social media, logo…" className="mt-2 h-12 rounded-xl bg-background" />
              </div>
              <div>
                <label className="eyebrow">Tell me about your project</label>
                <Textarea
                  required
                  name="message"
                  maxLength={4000}
                  rows={5}
                  placeholder="A few sentences on your idea, goals, or vision."
                  className="mt-2 rounded-xl bg-background"
                />
              </div>
              <Button type="submit" disabled={status === "sending"} className="h-12 rounded-full bg-accent text-accent-foreground hover:brightness-95 text-sm font-medium">
                {status === "sending" ? "Sending…" : status === "sent" ? "Message sent ✦" : "Send message"}
              </Button>
              <p role="status" aria-live="polite" className="min-h-5 text-sm text-muted-foreground">
                {status === "sent" && "Thank you! Your message is on its way and I'll be in touch soon."}
                {status === "error" && (
                  <>
                    Your message couldn&apos;t be sent just now. Please email me directly at{" "}
                    <a className="text-accent underline underline-offset-4" href={`mailto:${SITE.email}`}>{SITE.email}</a>.
                  </>
                )}
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="container-x py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <span className="grid h-7 w-7 place-items-center rounded-full bg-blush text-foreground font-display italic text-sm">
            W
          </span>
          <span>© {new Date().getFullYear()} Wendy&apos;s Portfolio. All rights reserved.</span>
        </div>
      </div>
    </footer>
  );
}
